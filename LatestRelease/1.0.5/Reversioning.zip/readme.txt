- unzip the content of the file into c:\program files (x86)\Wot Numbers folder
(You will need administrator permissions)

- Open a command line as administrator: 
Press Windows Key, then type cmd then press right mouse button to display a context menu, select "Run As Administrator"
 
- Go to Wot Number folder
cd "c:\program files (x86)\Wot Numbers"

- execute change_version batch file:
change_version.bat
